# Coded 3D toon short kit

Everything is code: three.js scenes rendered frame by frame in headless Chromium (Playwright), encoded with ffmpeg.

## Setup (once, in the working folder)
    npm install
    npx playwright install chromium      # skip if Chromium for Playwright is already installed
    pip install pocketsphinx numpy       # add --break-system-packages on managed Linux
    # ffmpeg must be on PATH (Windows: winget install Gyan.FFmpeg)

## Make a film
1. Write `script.json` ([["N","..."],["C","..."]]) and get the voice-over audio.
2. `python align.py voiceover.mp3 script.json`  -> data.js, mix.wav, vo.wav
3. Write `shots.js` (start from `example/shots_dwayne.js`): one `shot(t0, t1, (u, t, k) => {...})` per shot,
   ending with the DUR / END / renderFrame block from the example. Set END = audio length, DUR = END + 0.5.
4. `cat engine.js shots.js > film.js`   (Windows: `Get-Content engine.js, shots.js | Set-Content film.js`)
5. Storyboard: `node film-render.js board`  -> board/shot_NN.jpg + board/sheet.jpg. Get approval.
6. Checks: `node film-render.js shots` (start/mid/end of every shot -> checks/), or `node film-render.js still 12.5 30`.
7. Full render: `node film-render.js all` -> final.mp4 (WORKERS=3 for more parallel browsers, CPU=1 to force software GL).
   Finished parts in parts/ are skipped on re-run; delete parts/ after changing film.js.

## Engine notes
- `fit(box, {yaw, pitch, zoom, fov, roll})` frames a Box3 inside the safe area (above the caption band) and keeps the camera above the ground.
- `mv(box, k, from, to, hand)` blends camera params over the shot (k = 0..1); `cam(pos, look, fov, roll)` for manual cameras.
- Helpers: `put`, `boxOf`, `headBox`, `ptsBox`, `lerpBox`, `wp`, `shk`, `talk(t)` (mouth from the audio envelope), `walk(t)`, `pop(k)`,
  overlays `speed`, `confettiFall`, `dust`, `impact`, `flash`, `shakeLines`, `clockBlur`.
- Rigs: `human({...})` (pose/face/party hat), `makeRock`, `makeDragon`, `makeGriffin`, `makeCritter('cat'|'owl'|'fox'|'bunny'|'hamster')`, `makeRobot`.
