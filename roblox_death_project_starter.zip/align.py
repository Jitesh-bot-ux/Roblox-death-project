"""Align a voice-over to its script and write everything the engine needs.

usage: python align.py <audio> script.json [--tail 0.5]
script.json = [["N","In this town, everyone gets a pet."],["C","Hey. I'm Dwayne."], ...]  (N narrator, C co-star; spoken order)
writes: vo.wav, mix.wav (voice padded to audio+tail, loudnorm), data.js (WORDS, CHUNKS, ENV), words.json
needs: ffmpeg on PATH, pip install pocketsphinx numpy
"""
import json, re, subprocess, sys, wave
import numpy as np
from pocketsphinx import Decoder

audio, script = sys.argv[1], sys.argv[2]
tail = float(sys.argv[sys.argv.index('--tail') + 1]) if '--tail' in sys.argv else 0.5
run = lambda *a: subprocess.run(a, check=True)
run('ffmpeg', '-y', '-loglevel', 'error', '-i', audio, '-ac', '1', '-ar', '44100', 'vo.wav')
run('ffmpeg', '-y', '-loglevel', 'error', '-i', audio, '-ac', '1', '-ar', '16000', 'vo16.wav')
dur = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', 'vo.wav'], capture_output=True, text=True).stdout)
total = round(dur + tail, 2)
run('ffmpeg', '-y', '-loglevel', 'error', '-i', 'vo.wav', '-af', f'aformat=channel_layouts=stereo,apad=whole_dur={total},loudnorm=I=-15:TP=-1.5:LRA=11', '-ar', '44100', '-t', str(total), 'mix.wav')

# display tokens (keep punctuation for captions) and speaker per token
toks = []
for sp, phrase in json.load(open(script, encoding='utf-8')):
    for w in phrase.replace('-', ' ').split():
        toks.append((w.strip('"“”'), sp))
d = Decoder(samprate=16000, bestpath=False)
norm = lambda w: re.sub(r"[^a-z']", '', w.lower().replace('’', "'"))
words = [norm(w) for w, _ in toks]
missing = sorted({w for w in words if w and d.lookup_word(w) is None})
if missing:
    print('Not in the dictionary (spell them phonetically in script.json, e.g. "Dwayne" -> "Dwain"):', missing); sys.exit(1)
d.set_align_text(' '.join(w for w in words if w))
raw = wave.open('vo16.wav').readframes(10 ** 9)
d.start_utt(); d.process_raw(raw, full_utt=True); d.end_utt()
segs = [(s.start_frame / 100, s.end_frame / 100) for s in d.seg() if s.word not in ('<s>', '</s>', '<sil>', '(NULL)')]
kept = [t for t, w in zip(toks, words) if w]
assert len(segs) == len(kept), f'alignment returned {len(segs)} words for {len(kept)}'
W = [[round(a, 2), round(b, 2), t, s] for (a, b), (t, s) in zip(segs, kept)]
json.dump(W, open('words.json', 'w'))
# caption chunks: up to 3 words, break on punctuation or speaker change
ch, cur = [], []
for i, w in enumerate(W):
    cur.append(i); nx = W[i + 1] if i + 1 < len(W) else None
    if len(cur) == 3 or re.search(r'[.,?!…]$', w[2]) or not nx or nx[3] != w[3]:
        ch.append([W[cur[0]][0], W[cur[-1]][1], cur]); cur = []
# loudness envelope per frame (lip sync)
wv = wave.open('vo.wav'); sr = wv.getframerate(); a = np.frombuffer(wv.readframes(wv.getnframes()), dtype=np.int16).astype(float) / 32768
env = []
for f in range(int(total * 30) + 2):
    s = a[int(f / 30 * sr):int((f + 1) / 30 * sr)]; env.append(float(np.sqrt((s ** 2).mean())) if len(s) else 0.0)
env = np.array(env); env = np.clip(env / max(1e-6, np.percentile(env[env > 0.01], 95)), 0, 1)
open('data.js', 'w').write(f'export const WORDS={json.dumps(W)};\nexport const CHUNKS={json.dumps(ch)};\nexport const ENV={json.dumps([round(x, 2) for x in env])};\nexport const AUDIO_DUR={dur:.2f};\n')
print(f'{len(W)} words, {len(ch)} caption chunks, audio {dur:.2f}s, video {total}s -> data.js, mix.wav')
