// ---------- motion helpers ----------
const ss = x => x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x);
const cl = x => Math.max(0, Math.min(1, x));
const lerp = (a, b, k) => a + (b - a) * k;
const L3 = (a, b, k) => new V3(lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k));
const DEF = { yaw: 0, pitch: 0.1, zoom: 1, fov: 35, roll: 0 };
function mv(box, k, a, b = {}, hand = 0) {
  const q = ss(k), o = {};
  for (const key in DEF) { const va = a[key] ?? DEF[key], vb = b[key] ?? va; o[key] = va + (vb - va) * q; }
  if (hand) { o.yaw += Math.sin(T * 1.3) * 0.025 * hand; o.pitch += Math.sin(T * 1.7 + 1) * 0.018 * hand; }
  return fit(box, o);
}
const lerpBox = (a, b, k) => new THREE.Box3(a.min.clone().lerp(b.min, k), a.max.clone().lerp(b.max, k));
function shk(c, amp) { if (amp > 0) c.pos.add(new V3((hash(T * 97.3) - 0.5) * amp, (hash(T * 89.1 + 3) - 0.5) * amp, (hash(T * 83.7 + 7) - 0.5) * amp)); return c; }
const envAt = t => ENV[Math.min(ENV.length - 1, Math.max(0, Math.round(t * 30)))];
const talk = t => { const e = envAt(t); return e > 0.42 ? 'talk' : e > 0.14 ? 'o' : 'flat'; };
const pop = k => 1 + 0.45 * (1 - ss(k * 7));
function confettiFall(seed, t, n = 90) { const g = octx, cols = ['#ff4fa3', '#ffd21f', '#34c3ff', '#6ee06e', '#ff8a30']; for (let i = 0; i < n; i++) { const sp = 90 + hash(i + seed + 7) * 160; const y = (hash(i + seed + 50) * H * 0.7 + t * sp) % (H * 0.7); const x = hash(i + seed) * W + Math.sin(t * 2 + i) * 14; g.save(); g.translate(x, y); g.rotate(hash(i + seed + 99) * 6 + t * (2 + hash(i) * 4)); g.fillStyle = cols[i % 5]; g.fillRect(-7, -4, 14, 8); g.restore(); } }
function dust(t, n = 40) { const g = octx; for (let i = 0; i < n; i++) { const x = (hash(i + 600) * W + t * (30 + hash(i + 601) * 60)) % W; const y = H * 0.1 + hash(i + 602) * H * 0.55 + Math.sin(t * 1.5 + i) * 20; g.fillStyle = `rgba(255,220,180,${0.25 + hash(i + 603) * 0.4})`; g.beginPath(); g.arc(x, y, 2 + hash(i + 604) * 4, 0, 2 * PI); g.fill(); } }
const walk = (t, amp = 0.6, f = 9) => ({ lL: Math.sin(t * f) * amp, lR: -Math.sin(t * f) * amp, aLx: -Math.sin(t * f) * amp * 0.8, aRx: Math.sin(t * f) * amp * 0.8 });

// ---------- shots ----------
const S = [];
const shot = (t0, t1, fn) => S.push({ t0, t1, fn });

shot(0.00, 1.23, (u, t, k) => { // establishing, crane down
  put(guy, 1.6, 0, 3, -0.3); guy.face({ mouth: 'smile' });
  [[-2.2, 0.5, 0.4], [-0.3, -1.6, -0.2], [3.2, -0.5, -0.7], [-3.8, 3.2, 0.6], [0.3, 5, 2.8]].forEach(([x, z, r], i) => { put(EX[i], x, 0, z, r); EX[i].face({ mouth: i % 2 ? 'grin' : 'smile', eyes: i % 3 ? 'normal' : 'happy' }); EX[i].pose({ aLx: i === 2 ? -2.6 + Math.sin(t * 10) * 0.35 : 0, aRz: 0.15 }); });
  put(cat, -1, 2.6 + Math.sin(t * 6) * 0.12, -0.8, 0.4); cat.pose({ wing: 0.5 + Math.sin(t * 16) * 0.6 });
  return { cam: mv(ptsBox([[-4.8, 6.6, -11], [4.8, 6.6, -11], [-4, 0, 5.5], [4, 0, 5.5]]), k, { yaw: 0.02, pitch: 0.85, zoom: 1.18, fov: 42 }, { yaw: 0.18, pitch: 0.36, zoom: 1.0 }) };
});
shot(1.23, 2.95, (u, t, k) => { // gift opens, cat pops out
  const g = EX[0]; put(g, 0, 0, 0, 0); g.pose({ aLx: -1.05, aRx: -1.05, aLz: 0.18, aRz: 0.18 }); g.face({ eyes: 'wide', mouth: 'open', brow: 'up', blush: true });
  put(gift, 0, 1.3, 0.95); gift.userData.lid.visible = false; gift.userData.glow.visible = true; gift.userData.glow.material.opacity = 0.25 + 0.15 * Math.sin(t * 14);
  const q = ss(k * 1.7); put(cat, lerp(0.1, 0.95, q), lerp(1.45, 2.05, q) + Math.sin(t * 7) * 0.05, 1.1, -0.3); cat.pose({ wing: 0.5 + Math.sin(t * 18) * 0.6 }); cat.face({ eyes: 'happy', mouth: q > 0.5 ? 'open' : 'o' });
  return { cam: mv(boxOf([g, gift]).expandByPoint(new V3(1.3, 2.6, 1.1)), k, { yaw: -0.85, pitch: 0.1, zoom: 1.05, fov: 34 }, { yaw: -0.3 }) };
});
shot(2.95, 5.68, (u, t, k) => { // birthday row, pull out
  const pos = [[2.6, -2.2], [0.9, -0.6], [-0.8, 1.0], [-2.5, 2.6]];
  pos.forEach(([x, z], i) => { const e = EX[i + 1]; put(e, x, 0, z, -0.55); e.party.visible = true; e.face({ eyes: 'happy', mouth: i % 2 ? 'laugh' : 'grin', blush: i === 2 }); const w = Math.sin(t * 9 + i) * 0.3; e.pose({ aLx: i % 2 ? -2.7 + w : 0, aRx: i % 2 ? 0 : -2.7 + w, aLz: 0.2, aRz: 0.2, y: Math.abs(Math.sin(t * 6 + i)) * 0.08 }); });
  { const sh = wp(EX[2].arms[0]); put(owl, sh.x, sh.y + 0.25, sh.z, -0.6); } owl.face({ eyes: 'wide', mouth: 'o' }); owl.pose({ wing: 0.4 + Math.sin(t * 12) * 0.3 });
  put(fox, -1.7, 0, 1.9, -0.8); fox.face({ eyes: 'happy', mouth: 'smile' });
  put(bun, -3.4, Math.abs(Math.sin(t * 7)) * 0.3, 3.4, -0.6); bun.face({ eyes: 'normal', mouth: 'smile' });
  put(cat, 3.6, 1.8 + Math.sin(t * 5) * 0.15, -1.6, -0.6); cat.pose({ wing: 0.5 + Math.sin(t * 16) * 0.6 }); cat.face({ eyes: 'happy', mouth: 'open' });
  return { cam: mv(boxOf([EX[1], EX[2], EX[3], EX[4], bun, cat]), k, { yaw: -0.85, pitch: 0.5, zoom: 1.0, fov: 58 }, { yaw: -0.62, pitch: 0.58, zoom: 1.3 }), fx: () => confettiFall(3, t) };
});
shot(5.68, 7.79, (u, t, k) => { // friend + dragon lands
  put(pal, 0, 0, 0, 0.25); pal.pose({ aLz: 1.45, aRz: 2.5 + Math.sin(t * 5) * 0.1, tz: -0.05 }); pal.face({ eyes: 'happy', mouth: 'grin', brow: 'up' });
  const h = wp(pal.hands[0]); const q = ss(k * 1.8); put(drg, h.x - 0.05 + (1 - q) * 0.9, h.y + 0.05 + (1 - q) * 1.4, h.z + (1 - q) * 0.5, 0.5);
  drg.pose({ wing: q < 1 ? 0.5 + Math.sin(t * 20) * 0.7 : 0.9, fire: k > 0.55, hx: -0.35 });
  return { cam: mv(boxOf([pal]).expandByPoint(new V3(h.x + 0.9, h.y + 2.2, h.z + 0.5)), k, { yaw: -0.42, pitch: -0.32, zoom: 1.3, fov: 36 }, { yaw: -0.25, zoom: 1.03 }) };
});
shot(7.79, 10.01, (u, t, k) => { // a rock
  put(guy, 0, 0, 0, 0); guy.pose({ aLx: -1.15, aRx: -1.15, aLz: 0.2, aRz: 0.2, hx: 0.42 }); guy.face({ eyes: k > 0.45 ? 'half' : 'normal', mouth: k > 0.45 ? 'flat' : 'smile', ly: 0.6, sweat: k > 0.45 });
  put(gift, 0, 1.12, 0.98); gift.userData.lid.visible = false;
  put(dwayne, 0, 1.55, 1.0, 0, 0.8); dwayne.root.rotation.x = 0.5;
  return { cam: mv(ptsBox([[-0.6, 3.2, -0.3], [0.6, 1.1, 1.5]]), k, { yaw: 0.25, pitch: 0.55, zoom: 1.25, fov: 34 }, { yaw: 0.15, pitch: 1.12, zoom: 1.0 }) };
});
shot(10.01, 11.58, (u, t, k) => { // Hey I'm Dwayne
  put(guy, 0, 0, 0, 0); guy.pose({ aRx: -1.3, aRz: -0.15 }); guy.face({ eyes: 'half', mouth: 'flat' });
  const h = wp(guy.hands[1]); put(dwayne, h.x, h.y + 0.12, h.z + 0.02, 0); dwayne.face({ mouth: talk(t) });
  const p = wp(dwayne.root); return { cam: mv(ptsBox([[p.x, p.y + 0.62, p.z], [p.x, p.y - 0.15, p.z]], 0.42), k, { yaw: 0.05, pitch: 0.06, zoom: 1.18, fov: 30 }, { yaw: 0.18, zoom: 1.08 }, 1) };
});
shot(11.58, 12.55, (u, t, k) => { // Great.
  put(guy, 0, 0, 0, 0); guy.face({ eyes: 'half', mouth: 'flat', brow: 'flat' });
  return { cam: mv(headBox(guy), k, { yaw: -0.25, pitch: 0.42, zoom: 1.45, fov: 32 }, { zoom: 1.22 }) };
});
shot(12.55, 14.96, (u, t, k) => { // wind up
  put(guy, 8.5, 0, 7, -0.7); const q = ss(k * 1.2); guy.pose({ aRx: lerp(0.3, 2.5, q), aRz: 0.2, aLx: -1.1 * q, ty: 0.35 * q, lL: -0.4 * q, lR: 0.3 * q }); guy.face({ eyes: 'normal', mouth: 'grin', brow: 'angry' });
  const h = wp(guy.hands[1]); put(dwayne, h.x, h.y + 0.05, h.z, -0.7); dwayne.face({});
  return { cam: mv(boxOf([guy]).expandByScalar(0.4), k, { yaw: -0.9, pitch: -0.12, zoom: 1.1, fov: 36 }, { yaw: -0.4 }) };
});
shot(14.96, 16.01, (u, t, k) => { // thrown
  put(guy, 8.5, 0, 7, -0.7); guy.pose({ aRx: -1.6, aLx: 0.6, ty: -0.4, lL: 0.4, lR: -0.3 }); guy.face({ eyes: 'normal', mouth: 'open' });
  const p = L3([7.7, 2.5, 7.7], [6.2, 0.02, 10], k); p.y += Math.sin(PI * k) * 2.0; put(dwayne, p.x, p.y, p.z, 0.3); dwayne.root.rotation.z = t * 11; dwayne.root.rotation.x = t * 7;
  return { cam: mv(boxOf([guy]).expandByPoint(new V3(6.2, 0, 10)).expandByPoint(new V3(7, 3.6, 8.8)), k, { yaw: -0.95, pitch: 0.14, zoom: 1.02, fov: 44 }, { yaw: -0.75 }), fx: () => speed(W * 0.5, H * 0.3, 40) };
});
shot(16.01, 17.57, (u, t, k) => { // stayed there
  put(dwayne, 6.2, 0.02, 10, 0.6); dwayne.face({});
  put(guy, 7.8, 0, 8.6, -2.3); guy.pose({ aLz: 0.75, aRz: 0.75, hx: 0.45, lR: Math.max(0, Math.sin(t * 8)) * -0.25 }); guy.face({ eyes: 'half', mouth: 'flat', ly: 0.5 });
  put(leaf, lerp(8.6, 5.6, k), 0.06 + Math.abs(Math.sin(t * 4)) * 0.3, lerp(9.0, 10.4, k)); leaf.rotation.set(-PI / 2, 0, t * 3);
  return { cam: mv(boxOf([guy, dwayne]), k, { yaw: 0.25, pitch: 1.33, zoom: 1.12, fov: 34 }, { yaw: 0.85 }) };
});
shot(17.57, 19.55, (u, t, k) => { // Ow that hurt
  put(dwayne, 6.2, 0.02, 10, 0.3); dwayne.face({ mouth: talk(t), bandage: true });
  const p = wp(dwayne.root); return { cam: mv(ptsBox([[p.x, p.y + 0.55, p.z], [p.x, p.y, p.z]], 0.45), k, { yaw: 0.45, pitch: 0.02, roll: 0.09, zoom: 1.3, fov: 28 }, { yaw: 0.25, zoom: 1.1 }) };
});
shot(19.55, 21.38, (u, t, k) => { // pet race
  banner.visible = false; race.visible = true;
  put(drg, -3.4, 0, 1.5, PI, 1.25); drg.pose({ wing: 0.5 + Math.sin(t * 6) * 0.25 });
  put(grf, -1.0, 0, 1.8, PI, 0.85); grf.pose({ wing: 0.3, gallop: Math.sin(t * 5) * 0.1 });
  put(cat, 1.2, Math.abs(Math.sin(t * 6)) * 0.15, 1.6, PI); cat.face({ eyes: 'normal', mouth: 'smile' });
  put(fox, 2.6, 0, 1.6, PI); fox.face({ eyes: 'normal', mouth: 'grin' });
  put(dwayne, 4.0, 0.02, 1.7, PI); dwayne.face({});
  return { cam: mv(ptsBox([[-5.9, 5.8, 2], [5.9, 5.8, 2], [-5, 0, 0.5], [5, 0, 0.5]]), k, { yaw: PI - 0.22, pitch: 0.42, zoom: 1.0, fov: 46 }, { yaw: PI - 0.38, pitch: 0.62, zoom: 1.0 }) };
});
shot(21.38, 22.66, (u, t, k) => { // dragon flew
  banner.visible = false; race.visible = true;
  put(drg, 0.5, 4.6 - k * 0.5, lerp(1.5, 6.0, k), -0.3, 1.3); drg.pose({ wing: 0.6 + Math.sin(t * 24) * 0.8, hx: 0.2 }); drg.root.rotation.x = -0.35;
  put(EX[2], -1.8, 0, 2.0, 0.4); EX[2].face({ eyes: 'wide', mouth: 'o' }); EX[2].pose({ aLx: -2.6, aRx: -2.6, hx: -0.4 });
  put(EX[5], 2.2, 0, 1.0, -0.3); EX[5].face({ eyes: 'wide', mouth: 'open' }); EX[5].pose({ hx: -0.4 });
  EX[5].party.visible = true; EX[5].party.position.y = 1.4 + k * 1.2; EX[5].party.rotation.z = 0.8 + t * 6;
  return { cam: mv(boxOf([EX[2], EX[5]]).expandByPoint(new V3(0.5, 6.0, 6.5)), k, { yaw: 0.35, pitch: -0.42, zoom: 1.02, fov: 46 }, { yaw: 0.55 }), fx: () => speed(W * 0.5, H * 0.3, 40) };
});
shot(22.66, 24.20, (u, t, k) => { // griffin galloped
  banner.visible = false; const z = lerp(7.0, 1.5, k); put(grf, 1.5, 0.12 + Math.abs(Math.sin(t * 13)) * 0.18, z, PI); grf.pose({ gallop: Math.sin(t * 13) * 0.8, wing: 0.5 + Math.sin(t * 13) * 0.25, hx: -0.15 });
  return { cam: mv(boxOf([grf]), k, { yaw: -PI / 2 - 0.35, pitch: 0.06, zoom: 1.25, fov: 38 }, { yaw: -PI / 2 + 0.05 }), fx: () => speed(W * 0.2, H * 0.4, 36) };
});
shot(24.20, 27.32, (u, t, k) => { // 45 minutes, time-lapse push-in
  mood('gold'); banner.visible = false; race.visible = true; const mins = k * 45; drawClock(9 + mins / 60, mins % 60);
  sun.position.set(lerp(-26, 8, k), lerp(20, 12, k), 14);
  put(dwayne, 4.0, 0.02, 1.7, PI); dwayne.face({});
  const b = lerpBox(ptsBox([[4.0, 0, 1.7], [0, 13.4, -22], [-1.6, 10.3, -22]]), ptsBox([[4.0, 0.2, 1.7]], 1.1), ss(k));
  return { cam: fit(b, { yaw: 0.12, pitch: 0.12, fov: 40 }), fx: () => { if (k < 0.55) clockBlur(new V3(0, 11.9, -21.8)); } };
});
shot(27.32, 28.70, (u, t, k) => { // pacing myself
  mood('gold'); race.visible = true; banner.visible = false;
  put(dwayne, 4.0, 0.02, 1.7, PI); dwayne.face({ mouth: talk(t), sweat: true });
  const p = wp(dwayne.root); return { cam: mv(ptsBox([[p.x, p.y + 0.55, p.z], [p.x, p.y, p.z]], 0.45), k, { yaw: PI + 0.1, pitch: -0.06, zoom: 1.15, fov: 28 }, {}, 1) };
});
shot(28.70, 31.71, (u, t, k) => { // town laughs, orbit
  mood('gold'); put(guy, 0, 0, 1, 0); guy.pose({ aRx: -1.0 }); guy.face({ eyes: 'sad', mouth: 'frown', brow: 'sad', sweat: true });
  const h = wp(guy.hands[1]); put(dwayne, h.x, h.y + 0.1, h.z, 0); dwayne.face({});
  for (let i = 0; i < 8; i++) { const a = i / 8 * 2 * PI + 0.3, r = 4.2; const e = EX[i]; put(e, Math.sin(a) * r, 0, 1 + Math.cos(a) * r, a + PI); e.pose({ aRx: -1.55 + Math.sin(t * 12 + i) * 0.12, aLz: 0.6, tz: Math.sin(t * 13 + i) * 0.12, tx: Math.abs(Math.sin(t * 7 + i)) * 0.15 }); e.face({ eyes: 'happy', mouth: 'laugh' }); }
  return { cam: mv(ptsBox([[-4.6, 0, -3.4], [4.6, 3.2, 5.4]]), k, { yaw: 0.15, pitch: 0.72, fov: 40 }, { yaw: 1.05 }), fx: () => { impact('HA HA!', W * 0.24, 150, 64 * pop(k), '#ffd21f', -0.15); if (k > 0.2) impact('HAHA', W * 0.76, 210, 54 * pop(k - 0.2), '#ffffff', 0.12); } };
});
shot(31.71, 33.75, (u, t, k) => { // mayor's hamster, push-in
  mood('gold'); put(mayor, -6, 0.4, -1.4, 0); mayor.pose({ aLx: -0.6, aLz: 0.35, tx: -0.08 + Math.sin(t * 15) * 0.04 }); mayor.face({ eyes: 'happy', mouth: 'laugh' });
  const sh = wp(mayor.arms[1]); put(ham, sh.x - 0.02, sh.y + 0.24 + Math.abs(Math.sin(t * 14)) * 0.04, sh.z + 0.02, 0.15); ham.face({ eyes: 'happy', mouth: 'open', k: 1.3 }); ham.pose({ hz: Math.sin(t * 14) * 0.15 });
  const hp = wp(ham.root); const hb = headBox(mayor); hb.expandByPoint(hp.clone().add(new V3(-0.25, 0.42, 0))); hb.expandByPoint(hp.clone().add(new V3(0.2, -0.05, 0.2))); hb.expandByPoint(wp(mayor.torso).add(new V3(0, 0.1, 0)));
  const tight = headBox(mayor); tight.expandByPoint(hp.clone().add(new V3(-0.3, 0.45, 0))); tight.expandByPoint(hp.clone().add(new V3(0.2, -0.05, 0.2)));
  return { cam: fit(lerpBox(hb, tight, ss(k)), { yaw: -0.3, pitch: 0.04, zoom: 1.08, fov: 30 }), fx: () => { if (k > 0.3) impact('hee hee!', W * 0.3, 160, 52 * pop(k - 0.3), '#ffffff', -0.12); } };
});
shot(33.75, 37.00, (u, t, k) => { // put him down... walked away
  mood('gold');
  if (k < 0.45) {
    const q = ss(k / 0.35); put(guy, 7.6, 0, 5.55, PI); guy.pose({ tx: 0.55 * Math.min(1, k / 0.15 + 0.4), aRx: -0.9, hx: 0.35 }); guy.face({ eyes: 'sad', mouth: 'frown', brow: 'sad' });
    const h = wp(guy.hands[1]); const p = h.clone().lerp(ROCK_ON_BENCH, q); put(dwayne, p.x, p.y, p.z, 0);
  } else {
    const w = ss((k - 0.45) / 0.55); put(guy, lerp(7.6, 10.6, w), 0, lerp(5.55, 7.6, w), lerp(PI, 0.98, ss((k - 0.45) / 0.15))); guy.pose({ ...walk(t, 0.5 * Math.min(1, (k - 0.45) * 8), 7), hx: 0.3 }); guy.face({ eyes: 'sad', mouth: 'frown', brow: 'sad' });
    put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0);
  }
  dwayne.face({});
  return { cam: mv(boxOf([guy, bench1]), k, { yaw: -1.3, pitch: 0.08, zoom: 1.05, fov: 34 }, { yaw: -1.1, pitch: 0.2, fov: 42 }) };
});
shot(37.00, 39.30, (u, t, k) => { // ground shaking
  mood('atk'); put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y + Math.abs(Math.sin(t * 11)) * 0.06, ROCK_ON_BENCH.z, 0); dwayne.face({});
  put(guy, 5.4 + Math.sin(t * 9) * 0.1, 0, 9.4, 0.4); guy.pose({ aLz: 1.2 + Math.sin(t * 11) * 0.3, aRz: 1.0 + Math.cos(t * 10) * 0.3, lL: 0.4, lR: -0.3, tz: 0.15 * Math.sin(t * 6) }); guy.face({ eyes: 'wide', mouth: 'open', brow: 'up' });
  put(pebbles, 7, 0, 6.5); pebbles.children.forEach((p, i) => { p.userData.by ??= p.position.y; p.position.y = 0.1 + Math.abs(Math.sin(t * 9 + i)) * 0.7; });
  drops.children.forEach((d, i) => d.position.y = 2.6 + Math.abs(Math.sin(t * 8 + i)) * 0.9);
  return { cam: shk(cam(L3([2.4, 3.0, 14.3], [2.0, 2.8, 14.8], k).toArray(), [6.6, 1.5, 6.6], 52, lerp(0.12, 0.26, k)), 0.22), fx: shakeLines };
});
shot(39.30, 41.74, (u, t, k) => { // robot stomps
  mood('atk'); banner.visible = false; const q = ss(k / 0.6); put(bot, -5, 0, lerp(-14, -12.6, q), 0.45); bot.pose({ lL: lerp(-0.6, 0, q), lR: lerp(0.25, 0.05, q), aLx: lerp(-0.4, 0.2, q), aRx: lerp(0.3, -0.2, q) });
  const land = k > 0.6 ? Math.max(0, 1 - (k - 0.6) * 3) : 0;
  return { cam: shk(mv(boxOf([bot]), k, { yaw: 0.25, pitch: -0.6, zoom: 1.03, fov: 58 }, { yaw: 0.35, pitch: -0.4 }), land * 0.8), fx: () => { if (k > 0.6) impact('STOMP!', W * 0.72, 170, 70 * pop(k - 0.6), '#ff5a3a', 0.12); } };
});
shot(41.74, 43.65, (u, t, k) => { // everyone ran
  mood('atk'); banner.visible = false;
  for (let i = 0; i < 6; i++) { const a = i / 6 * 2 * PI + 0.5, r = 2.2 + (i % 3) * 1.4 + k * 2.4; const e = EX[i]; put(e, Math.sin(a) * r, 0, 2 + Math.cos(a) * r, a); e.pose({ ...walk(t + i, 0.75, 13), aLx: -2.7, aRx: -2.7 }); e.face({ eyes: 'wide', mouth: 'open', brow: 'up' }); }
  put(cat, 0.4 + k * 2, Math.abs(Math.sin(t * 12)) * 0.2, 2.3 + k * 1.5, 2.5); cat.face({ eyes: 'wide', mouth: 'open' }); put(fox, -2.8 - k * 2, 0, 4.3 + k * 1.5, -2.2); fox.face({ eyes: 'wide', mouth: 'open' }); put(bun, 3.0 + k * 1.5, Math.abs(Math.sin(t * 10)) * 0.4, -0.2 - k * 2, 1.2); bun.face({ eyes: 'wide', mouth: 'o' });
  return { cam: shk(mv(ptsBox([[-6, 0, -3.5], [6, 3, 7.5]]), k, { yaw: 0.1, pitch: 1.28, roll: 0.3, fov: 38 }, { yaw: 0.45, roll: 0.62 }), 0.15) };
});
shot(43.65, 44.90, (u, t, k) => { // dragon cried
  mood('atk'); banner.visible = false; put(pal, 0, 0, 2, 0); pal.pose({ aLx: -1.2, aRx: -1.2, aLz: 0.3, aRz: 0.3 }); pal.face({ eyes: 'sad', mouth: 'frown', brow: 'sad' });
  put(drg, 0, 1.55 + Math.abs(Math.sin(t * 9)) * 0.05, 2.75, 0, 1.0); drg.pose({ wing: 0.1, tears: true, hx: -0.3 + Math.sin(t * 9) * 0.06 });
  const hb = headBox(pal); hb.expandByPoint(new V3(0.6, 1.4, 3.4)); hb.expandByPoint(new V3(-0.6, 2.9, 3.4)); return { cam: mv(hb, k, { yaw: 0.08, pitch: 0.02, zoom: 1.12, fov: 32 }, { zoom: 1.02 }, 1) };
});
shot(44.90, 46.79, (u, t, k) => { // griffin hides
  mood('atk'); put(grf, -7 + (hash(t * 40) - 0.5) * 0.05, -0.35, 6.4, PI, 0.85); grf.pose({ wing: 0.05, hx: 0.25 }); grf.legs.forEach(l => l.rotation.x = 0);
  return { cam: mv(boxOf([grf, bench2]), k, { yaw: 1.05, pitch: 0.28, zoom: 1.06, fov: 36 }, { yaw: 0.5 }) };
});
shot(46.79, 47.95, (u, t, k) => { // turned around
  mood('atk'); const q = ss(k * 1.3); put(guy, 5.4, 0, 9.4, lerp(-1.0, -2.4, q)); guy.pose({ ty: 0.5 * q, hy: 0.35 * q, aLz: 0.4, aRz: 0.3 }); guy.face({ eyes: q > 0.5 ? 'wide' : 'normal', mouth: q > 0.5 ? 'o' : 'flat', brow: q > 0.5 ? 'up' : null, sweat: q > 0.5 });
  const hb = headBox(guy); hb.expandByPoint(wp(guy.torso).add(new V3(0, 0.3, 0))); return { cam: mv(hb, k, { yaw: -1.25, pitch: 0.1, zoom: 1.15, fov: 32 }, { yaw: -1.75 }) };
});
shot(47.95, 49.93, (u, t, k) => { // still sitting there
  mood('atk'); banner.visible = false; put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0); dwayne.face({});
  put(bot, 6.5, 0, -9, -0.1); bot.pose({ aLx: -0.5, aRx: -0.3, hx: 0.25 + Math.sin(t * 2) * 0.03 });
  return { cam: cam(L3([7.62, 1.7, 7.3], [7.62, 1.45, 6.3], ss(k)).toArray(), [7.0, 4.3, -6], 80) };
});
shot(49.93, 51.72, (u, t, k) => { // Go. I've got this.
  mood('atk'); put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0); dwayne.face({ mouth: talk(t), brow: 'angry' });
  rim.position.set(7.2, 2.0, 3.2); rim.intensity = 8; rim.color.set(0xffc080);
  const p = wp(dwayne.root); return { cam: mv(ptsBox([[p.x, p.y + 0.55, p.z], [p.x, p.y, p.z]], 0.42), k, { yaw: 0.1, pitch: -0.28, zoom: 1.18, fov: 28 }, { yaw: 0.55, zoom: 1.12 }), fx: () => dust(t) };
});
shot(51.72, 53.18, (u, t, k) => { // one step
  mood('atk'); banner.visible = false; put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0); dwayne.face({ eyes: 'half', mouth: 'flat' });
  put(bot, 7.6, 0, -1.2, 0); bot.pose({ lL: 0, lR: lerp(-1.2, -0.85, ss(k)), aLx: 0.3, aRx: -0.3, tx: 0.05 * k });
  return { cam: shk(cam(L3([12.2, 0.7, 9.8], [11.4, 0.55, 8.9], ss(k)).toArray(), [7.6, 2.9, 3.6], 60), k > 0.8 ? 0.3 : 0), fx: () => { if (k > 0.75) impact('THOOM', W * 0.7, 170, 64 * pop(k - 0.75), '#ffffff', 0.1); } };
});
shot(53.18, 54.46, (u, t, k) => { // tripped
  mood('atk'); put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0); dwayne.face({ eyes: 'half', mouth: 'flat' });
  put(bot, 7.6, 0, 1.6, 0); bot.root.rotation.x = lerp(0.2, 0.8, ss(k)); bot.pose({ lL: 0.7, lR: -0.3, aLx: -2.5 + Math.sin(t * 14) * 0.4, aRx: -2.2 + Math.cos(t * 13) * 0.4, aLz: 0.6, aRz: 0.6, hx: -0.3 });
  return { cam: shk(mv(boxOf([bot, bench1]), k, { yaw: -1.0, pitch: 0.45, roll: 0.12, fov: 60 }, { roll: 0.26 }), 0.12), fx: () => impact('CLANK!', W * 0.3, 160, 66 * pop(k), '#ffd21f', -0.15) };
});
shot(54.46, 57.18, (u, t, k) => { // explosion
  mood('atk'); put(dwayne, ROCK_ON_BENCH.x, ROCK_ON_BENCH.y, ROCK_ON_BENCH.z, 0); dwayne.face({});
  put(debris, 7.6, 0, -3); const f = 0.3 + 1.0 * ss(k * 1.3), n = debris.children.length;
  debris.children.forEach((c, i) => { c.userData.base ??= c.position.clone(); c.userData.r0 ??= c.rotation.clone(); if (i >= n - 2) { c.scale.setScalar(1 + k * 0.8); c.visible = k < 0.6; if (c.material.transparent) c.material.opacity = 0.85 * (1 - k / 0.6); return; } c.position.copy(c.userData.base).multiplyScalar(f); c.position.y = Math.max(0.3, c.userData.base.y * f - k * k * 3); c.rotation.set(c.userData.r0.x + t * 2, c.userData.r0.y + t * 1.5, 0); });
  return { cam: shk(mv(ptsBox([[-2, 0, -9], [17, 13, 4]]), k, { yaw: 0.65, pitch: 0.18, fov: 46, zoom: 1.0 }, { yaw: 0.85, zoom: 1.28 }), Math.max(0, 0.9 - k * 1.5)), fx: () => { flash(Math.max(0, 0.75 - k * 2.5)); impact('KABOOM!', W / 2, 190, 104 * pop(k), '#ff7a1a', -0.06); } };
});
shot(57.18, 59.60, (u, t, k) => { // statue (draped), crane up
  mood('gold'); banner.visible = false; fountain.visible = false; ped.visible = true; drape.visible = true; drape.position.y = 4.2;
  const cr = [[-3.6, 0.6], [-1.8, 1.4], [0.3, 2.0], [2.2, 1.2], [3.8, 0.4], [-0.8, 3.4]]; cr.forEach(([x, z], i) => { const e = EX[i]; put(e, x, 0, z, PI + x * 0.08); e.pose({ aLx: -2.8 + Math.sin(t * 9 + i) * 0.25, aRx: -2.8 + Math.cos(t * 9 + i) * 0.25, aLz: 0.3, aRz: 0.3, y: Math.abs(Math.sin(t * 6 + i)) * 0.12 }); e.face({ eyes: 'happy', mouth: 'laugh' }); });
  return { cam: mv(ptsBox([[-4.2, 0, -8], [4.2, 6.4, 3.5]]), k, { yaw: 0.05, pitch: -0.08, fov: 54 }, { yaw: 0.18, pitch: 0.22 }), fx: () => confettiFall(11, t) };
});
shot(59.60, 61.70, (u, t, k) => { // just a bigger rock, pull out
  mood('gold'); banner.visible = false; fountain.visible = false; ped.visible = true; statue.visible = true;
  drape.visible = k < 0.2; drape.position.y = 4.2 + k * 30;
  put(guy, 2.9, 0, -2.6, -0.45); guy.pose({ hx: -0.45 }); guy.face({ eyes: 'half', mouth: 'flat', ly: -0.6 });
  const b = lerpBox(ptsBox([[-2.0, 1.6, -6], [2.0, 4.6, -4.2]]), ptsBox([[-2.2, 0, -8], [3.4, 4.6, -2.0]]), ss(k));
  return { cam: fit(b, { yaw: lerp(0.15, 0.35, ss(k)), pitch: 0.08, fov: 46 }) };
});
shot(61.70, 64.30, (u, t, k) => { // didn't even feel it
  mood('gold'); banner.visible = false; fountain.visible = false; ped.visible = true; statue.visible = true;
  put(guy, -0.5, 1.12, -4.7, 0.1); guy.pose({ lL: -1.5 + Math.sin(t * 4) * 0.15, lR: -1.5 - Math.sin(t * 4) * 0.15, aRz: 0.15, aLz: 0.15 }); guy.face({ eyes: 'happy', mouth: 'smile' });
  put(dwayne, 0.65, 2.3, -4.55, -0.15); dwayne.face({ mouth: talk(t) });
  const hb = headBox(guy); hb.expandByObject(dwayne.root); return { cam: mv(hb, k, { yaw: 0.3, pitch: 0.04, zoom: 1.12, fov: 32 }, { yaw: 0.18, zoom: 1.05 }, 1) };
});

const END = AUDIO_DUR, DUR = Math.round((AUDIO_DUR + 0.5) * 100) / 100;
window.SHOT_COUNT = S.length;
window.SHOTS = S.map(s => [s.t0, s.t1]);
window.DUR = DUR;
function draw(t) {
  T = t; octx.setTransform(1.5, 0, 0, 1.5, 0, 0);
  if (t >= END) { octx.fillStyle = '#000'; octx.fillRect(0, 0, W, H); return; }
  let s = S.find(s => t >= s.t0 && t < s.t1) || S[S.length - 1];
  reset(); const u = t - s.t0, k = cl(u / (s.t1 - s.t0)); const r = s.fn(u, t, k);
  ACT.forEach((a, i) => { if (a.kind === 'human' && a.root.visible) a.head.rotation.z += Math.sin(t * 1.6 + i) * 0.035; });
  applyCam(r.cam); renderer.render(scene, camera);
  octx.drawImage(renderer.domElement, 0, 0, W, H); vignette(); r.fx && r.fx(); caption(t);
}
window.renderFrame = t => { draw(t); return out.toDataURL('image/jpeg', 0.92); };
window.renderShot = (i, tt) => { const s = S[i - 1]; return window.renderFrame(tt ?? (s.t0 + s.t1) / 2); };
document.fonts.load('900 60px InterB').then(() => { window.ready = true; });
